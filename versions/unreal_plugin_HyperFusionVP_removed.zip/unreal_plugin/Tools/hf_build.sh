#!/usr/bin/env bash
# Build HyperFusionVP and leave the module manifest pointing at what was built.
#
# Why this wrapper exists: successive builds emit numbered libraries
# (libUnrealEditor-HyperFusionVP-0002.so) but UBT only rewrites
# Binaries/Linux/UnrealEditor.modules on a clean build. When the editor is
# holding the module open — which it is, whenever you are testing — the manifest
# keeps naming an older number and the editor silently loads stale code on the
# next launch. The build still reports Succeeded, so it reads as "my change did
# nothing" rather than as a build problem.
#
# Usage:
#   ./hf_build.sh            build, then repair the manifest
#   ./hf_build.sh --clean    wipe binaries first (editor must be closed)

set -euo pipefail

UE="${UE_ROOT:-/home/kiransai/UnrealEngine_5.8.1}"
PROJ="${HF_PROJECT:-/home/kiransai/Documents/Unreal Projects/MyProject}"
UPROJECT="$PROJ/MyProject.uproject"
BIN="$PROJ/Plugins/HyperFusionVP/Binaries/Linux"

editor_running() { pgrep -f "UnrealEditor.*MyProject" >/dev/null 2>&1; }

if [[ "${1:-}" == "--clean" ]]; then
    if editor_running; then
        echo "error: close the Unreal editor before a clean build (it holds the module open)" >&2
        exit 1
    fi
    echo "==> wiping build artifacts"
    rm -rf "$PROJ/Plugins/HyperFusionVP/Binaries" \
           "$PROJ/Plugins/HyperFusionVP/Intermediate" \
           "$PROJ/Binaries" "$PROJ/Intermediate/Build"
fi

echo "==> building MyProjectEditor"
"$UE/Engine/Build/BatchFiles/Linux/Build.sh" MyProjectEditor Linux Development \
    -Project="$UPROJECT" -Progress

# Repair the manifest: name the highest-numbered library actually on disk.
if [[ -f "$BIN/UnrealEditor.modules" ]]; then
    python3 - "$BIN" <<'PY'
import json, os, re, sys
bin_dir = sys.argv[1]
manifest = os.path.join(bin_dir, "UnrealEditor.modules")
data = json.load(open(manifest))
libs = [f for f in os.listdir(bin_dir)
        if re.fullmatch(r"libUnrealEditor-HyperFusionVP-\d+\.so", f)]
if not libs:
    sys.exit(0)
newest = max(libs, key=lambda f: int(re.search(r"-(\d+)\.so$", f).group(1)))
current = data["Modules"].get("HyperFusionVP")
if current == newest:
    print(f"==> manifest already current ({newest})")
else:
    data["Modules"]["HyperFusionVP"] = newest
    json.dump(data, open(manifest, "w"), indent="\t")
    print(f"==> manifest repaired: {current} -> {newest}")
PY
fi

if editor_running; then
    echo
    echo "NOTE: the editor is running. Restart it — stopping PIE is not enough to"
    echo "      pick up a rebuilt module."
fi

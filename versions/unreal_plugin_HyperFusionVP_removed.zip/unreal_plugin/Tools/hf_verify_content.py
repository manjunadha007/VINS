"""
Checks that the generated HyperFusionVP assets are wired the way the C++ expects.

Existence is not the interesting question — a Blueprint with the wrong parent or
a material missing the "VideoTexture" parameter will load fine and then silently
show nothing. This asserts the parts the runtime actually depends on.

    <UE>/Engine/Binaries/Linux/UnrealEditor-Cmd "<project>/MyProject.uproject" \
        -run=pythonscript -script="<this file>"

Exits non-zero if anything is wrong.
"""

import unreal


PLUGIN_ROOT = "/HyperFusionVP/HyperFusionVP"

failures = []
checks = 0

# A commandlet starts with an unpopulated asset registry, so plugin content is
# invisible until it is scanned explicitly. Without this every load_asset below
# returns None and the run reports four phantom failures.
_registry = unreal.AssetRegistryHelpers.get_asset_registry()
_registry.scan_paths_synchronous([PLUGIN_ROOT], force_rescan=True)
unreal.log("[verify] registry sees under {}:".format(PLUGIN_ROOT))
for _a in _registry.get_assets_by_path(PLUGIN_ROOT, recursive=True):
    unreal.log("[verify]   {}".format(_a.get_editor_property("package_name")))


def check(condition, description):
    global checks
    checks += 1
    if condition:
        unreal.log("[verify] PASS  {}".format(description))
    else:
        unreal.log_error("[verify] FAIL  {}".format(description))
        failures.append(description)


def load(path):
    asset = unreal.EditorAssetLibrary.load_asset(path)
    check(asset is not None, "{} loads".format(path))
    return asset


# ── Material ────────────────────────────────────────────────────────────────

mat = load(PLUGIN_ROOT + "/Materials/M_CameraOverlay")
if mat:
    check(mat.get_editor_property("blend_mode") == unreal.BlendMode.BLEND_TRANSLUCENT,
          "M_CameraOverlay is translucent")
    check(mat.get_editor_property("shading_model") == unreal.MaterialShadingModel.MSM_UNLIT,
          "M_CameraOverlay is unlit")

    tex_params = unreal.MaterialEditingLibrary.get_texture_parameter_names(mat)
    scalar_params = unreal.MaterialEditingLibrary.get_scalar_parameter_names(mat)
    # These names are duplicated in HFTrackedCamera.cpp; a mismatch means the
    # overlay renders untextured or stuck at one opacity.
    check("VideoTexture" in [str(p) for p in tex_params],
          "M_CameraOverlay exposes texture param 'VideoTexture' (found {})".format(
              [str(p) for p in tex_params]))
    check("Opacity" in [str(p) for p in scalar_params],
          "M_CameraOverlay exposes scalar param 'Opacity' (found {})".format(
              [str(p) for p in scalar_params]))


# ── Blueprints ──────────────────────────────────────────────────────────────

def check_parent(asset_path, expected_class):
    """Neither UBlueprint.parent_class nor BlueprintGeneratedClass.get_super_class
    is exposed to Python in 5.8, so ask the question of the CDO instead: an
    isinstance check answers 'does this Blueprint actually behave as our class'
    rather than 'is our class its immediate parent', which is what we care about."""
    bp = load(asset_path)
    if not bp:
        return None

    gen = bp.generated_class()
    if not gen:
        check(False, "{} has a generated class".format(asset_path))
        return None

    cdo = unreal.get_default_object(gen)
    check(isinstance(cdo, expected_class),
          "{} derives from {} (got {})".format(
              asset_path, expected_class.__name__, type(cdo).__name__))
    return bp


check_parent(PLUGIN_ROOT + "/Blueprints/BP_TrackingOrigin", unreal.HFTrackingOrigin)
cam_bp = check_parent(PLUGIN_ROOT + "/Blueprints/BP_TrackedCamera", unreal.HFTrackedCamera)
check_parent(PLUGIN_ROOT + "/UI/WBP_AlignmentPanel", unreal.HFAlignmentPanel)

if cam_bp:
    cdo = unreal.get_default_object(cam_bp.generated_class())

    overlay = cdo.get_editor_property("OverlayMaterial")
    check(overlay is not None,
          "BP_TrackedCamera has OverlayMaterial assigned (got {})".format(overlay))

    # The asset predates OverlayMode, so this confirms it inherits the C++ default
    # rather than having baked in a stale value that would need regenerating.
    mode = cdo.get_editor_property("OverlayMode")
    check(mode == unreal.HFOverlayMode.SCREEN_SPACE,
          "BP_TrackedCamera OverlayMode is ScreenSpace (got {})".format(mode))

    overlay_widget = cdo.get_editor_property("ScreenOverlayClass")
    check(overlay_widget is not None,
          "BP_TrackedCamera has a ScreenOverlayClass (got {})".format(overlay_widget))

    # Without a LiveLink controller the camera receives no pose and never moves,
    # however healthy the video feed looks.
    check(cdo.get_editor_property("LiveLinkController") is not None,
          "BP_TrackedCamera has a LiveLinkController component")

    check(cdo.get_editor_property("bTakeViewOnPlay") is True,
          "BP_TrackedCamera takes the view on Play")


# ── Summary ─────────────────────────────────────────────────────────────────

if failures:
    unreal.log_error("[verify] {} of {} checks FAILED:".format(len(failures), checks))
    for f in failures:
        unreal.log_error("[verify]   - {}".format(f))
    raise SystemExit(1)

# Warning level, not Display: a commandlet filters Display out of the log, and a
# verification run that prints nothing on success is indistinguishable from one
# that never executed.
unreal.log_warning("[verify] all {} checks passed".format(checks))

"""
Generates the HyperFusionVP content assets.

Unreal assets are binary .uasset files, so they cannot be written by hand — this
script builds them through the editor's own asset API instead. It is idempotent:
re-running it skips anything that already exists unless --force is passed.

Creates, under Plugins/HyperFusionVP/Content/HyperFusionVP/:

    Materials/M_CameraOverlay    translucent unlit, params "VideoTexture" + "Opacity"
    Blueprints/BP_TrackingOrigin subclass of AHFTrackingOrigin
    Blueprints/BP_TrackedCamera  subclass of AHFTrackedCamera, overlay material assigned
    UI/WBP_AlignmentPanel        subclass of UHFAlignmentPanel

Run it either way:

    # from the editor: Tools > Execute Python Script, pick this file
    # or headless:
    <UE>/Engine/Binaries/Linux/UnrealEditor-Cmd \
        "<project>/MyProject.uproject" \
        -run=pythonscript -script="<this file>"

The Widget Blueprint is created with the right parent class but no layout: there
is no supported API for building a widget tree from Python. Open it and add the
controls named in PANEL_WIDGETS below — UHFAlignmentPanel binds them by name and
tolerates any that are missing.
"""

import sys

import unreal


PLUGIN_ROOT = "/HyperFusionVP/HyperFusionVP"
MATERIAL_PATH = PLUGIN_ROOT + "/Materials"
BLUEPRINT_PATH = PLUGIN_ROOT + "/Blueprints"
UI_PATH = PLUGIN_ROOT + "/UI"

# Widget names UHFAlignmentPanel binds to (all BindWidgetOptional).
PANEL_WIDGETS = [
    ("StatusText",       "TextBlock", "TRACKING / WAITING / LOST, colour-coded"),
    ("FpsText",          "TextBlock", "SLAM -> FreeD rate readout"),
    ("MarkerText",       "TextBlock", "ArUco status"),
    ("GpuReminderText",  "TextBlock", "FPS cap notice"),
    ("OverlayToggle",    "CheckBox",  "show/hide camera feed"),
    ("OpacitySlider",    "Slider",    "0..1 overlay opacity"),
    ("StorePoseButton",  "Button",    "lock alignment"),
    ("ResetPoseButton",  "Button",    "clear alignment"),
    ("SliderX",          "Slider",    "offset X, 0.5 = neutral"),
    ("SliderY",          "Slider",    "offset Y, 0.5 = neutral"),
    ("SliderZ",          "Slider",    "offset Z, 0.5 = neutral"),
    ("SliderRoll",       "Slider",    "roll, 0.5 = neutral"),
    ("SliderPitch",      "Slider",    "pitch, 0.5 = neutral"),
    ("SliderYaw",        "Slider",    "yaw, 0.5 = neutral"),
    ("SliderScale",      "Slider",    "scale, 0.5 = 1.0x"),
]

FORCE = "--force" in sys.argv

log = unreal.log
warn = unreal.log_warning
err = unreal.log_error


# ──────────────────────────────────────────────────
# helpers
# ──────────────────────────────────────────────────

def asset_tools():
    return unreal.AssetToolsHelpers.get_asset_tools()


def scan_registry():
    """Populate the asset registry for our content path.

    A commandlet starts with an empty registry, so does_asset_exist() reports
    False for assets that are sitting right there on disk. The script then tries
    to create them, and create_asset fails on the existing package — turning a
    re-run into four errors instead of four skips.
    """
    try:
        registry = unreal.AssetRegistryHelpers.get_asset_registry()
        registry.scan_paths_synchronous([PLUGIN_ROOT], force_rescan=True)
    except Exception as e:  # noqa: BLE001 - nothing to scan on a first run
        log("[hf] registry scan skipped: {}".format(e))


def exists(package_path, name):
    return unreal.EditorAssetLibrary.does_asset_exist("{}/{}".format(package_path, name))


def prepare(package_path, name):
    """Returns True if we should create this asset."""
    full = "{}/{}".format(package_path, name)
    if exists(package_path, name):
        if not FORCE:
            log("[hf] skip {} (already exists)".format(full))
            return False
        log("[hf] --force: deleting {}".format(full))
        unreal.EditorAssetLibrary.delete_asset(full)
    if not unreal.EditorAssetLibrary.does_directory_exist(package_path):
        unreal.EditorAssetLibrary.make_directory(package_path)
    return True


def find_class(name):
    """Resolve a C++ class exposed to Python, with a clear error if the plugin
    module failed to load (which otherwise shows up as a confusing AttributeError)."""
    cls = getattr(unreal, name, None)
    if cls is None:
        err("[hf] class '{}' not found. Is the HyperFusionVP module compiled and loaded?".format(name))
    return cls


# ──────────────────────────────────────────────────
# M_CameraOverlay
# ──────────────────────────────────────────────────

def build_material():
    name = "M_CameraOverlay"
    if not prepare(MATERIAL_PATH, name):
        return unreal.EditorAssetLibrary.load_asset("{}/{}".format(MATERIAL_PATH, name))

    mat = asset_tools().create_asset(name, MATERIAL_PATH, unreal.Material,
                                     unreal.MaterialFactoryNew())
    if not mat:
        err("[hf] failed to create material")
        return None

    # Unlit + translucent: this is a video feed composited over the shot, it must
    # not pick up scene lighting or write depth.
    mat.set_editor_property("blend_mode", unreal.BlendMode.BLEND_TRANSLUCENT)
    mat.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)
    mat.set_editor_property("two_sided", True)

    mel = unreal.MaterialEditingLibrary

    tex_param = mel.create_material_expression(
        mat, unreal.MaterialExpressionTextureSampleParameter2D, -400, 0)
    tex_param.set_editor_property("parameter_name", "VideoTexture")

    opacity_param = mel.create_material_expression(
        mat, unreal.MaterialExpressionScalarParameter, -400, 250)
    opacity_param.set_editor_property("parameter_name", "Opacity")
    opacity_param.set_editor_property("default_value", 0.5)

    mel.connect_material_property(tex_param, "RGB", unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    mel.connect_material_property(opacity_param, "", unreal.MaterialProperty.MP_OPACITY)

    mel.recompile_material(mat)
    unreal.EditorAssetLibrary.save_loaded_asset(mat)
    log("[hf] created {}/{}".format(MATERIAL_PATH, name))
    return mat


# ──────────────────────────────────────────────────
# Blueprints
# ──────────────────────────────────────────────────

def build_blueprint(name, package_path, parent_class, factory=None):
    if not prepare(package_path, name):
        return unreal.EditorAssetLibrary.load_asset("{}/{}".format(package_path, name))

    if parent_class is None:
        return None

    factory = factory or unreal.BlueprintFactory()
    factory.set_editor_property("parent_class", parent_class)

    asset_class = unreal.WidgetBlueprint if isinstance(factory, unreal.WidgetBlueprintFactory) \
        else unreal.Blueprint

    bp = asset_tools().create_asset(name, package_path, asset_class, factory)
    if not bp:
        err("[hf] failed to create {}".format(name))
        return None

    unreal.EditorAssetLibrary.save_loaded_asset(bp)
    log("[hf] created {}/{}".format(package_path, name))
    return bp


def refresh_blueprints(blueprints):
    """Recompile the Blueprints against the current native parent classes.

    Scalar properties added to a C++ parent show up in an existing Blueprint for
    free, but a new component subobject does not: the generated class keeps the
    component set it was compiled with. Without this, adding something like
    LiveLinkController to AHFTrackedCamera leaves BP_TrackedCamera silently
    lacking it at runtime.
    """
    if not hasattr(unreal, "BlueprintEditorLibrary"):
        warn("[hf] BlueprintEditorLibrary unavailable — recompile the Blueprints by hand "
             "after any C++ change that adds or removes a component")
        return

    for bp in blueprints:
        if not bp:
            continue
        try:
            unreal.BlueprintEditorLibrary.compile_blueprint(bp)
            unreal.EditorAssetLibrary.save_loaded_asset(bp)
            log("[hf] recompiled {}".format(bp.get_name()))
        except Exception as e:  # noqa: BLE001 - editor API raises bare Exception
            warn("[hf] could not recompile {}: {}".format(bp.get_name(), e))


def assign_overlay_material(camera_bp, material):
    """Set OverlayMaterial on the Blueprint's class defaults."""
    if not camera_bp or not material:
        return
    try:
        cdo = unreal.get_default_object(camera_bp.generated_class())
        cdo.set_editor_property("OverlayMaterial", material)
        unreal.EditorAssetLibrary.save_loaded_asset(camera_bp)
        log("[hf] assigned M_CameraOverlay to BP_TrackedCamera")
    except Exception as e:  # noqa: BLE001 - editor API raises bare Exception
        warn("[hf] could not assign OverlayMaterial automatically: {}".format(e))
        warn("[hf] set it by hand on BP_TrackedCamera > HyperFusion|Overlay")


# ──────────────────────────────────────────────────

def main():
    log("[hf] building HyperFusionVP content{}".format(" (--force)" if FORCE else ""))

    scan_registry()

    material = build_material()

    origin_class = find_class("HFTrackingOrigin")
    camera_class = find_class("HFTrackedCamera")
    panel_class = find_class("HFAlignmentPanel")

    if not (origin_class and camera_class and panel_class):
        err("[hf] aborting: plugin classes unavailable")
        return

    origin_bp = build_blueprint("BP_TrackingOrigin", BLUEPRINT_PATH, origin_class)
    camera_bp = build_blueprint("BP_TrackedCamera", BLUEPRINT_PATH, camera_class)
    panel_bp = build_blueprint("WBP_AlignmentPanel", UI_PATH, panel_class,
                               factory=unreal.WidgetBlueprintFactory())

    assign_overlay_material(camera_bp, material)
    refresh_blueprints([origin_bp, camera_bp, panel_bp])

    log("")
    log("[hf] done. Remaining manual step — open WBP_AlignmentPanel and add these")
    log("[hf] widgets (names must match exactly; any you omit are simply inert):")
    for widget_name, widget_type, purpose in PANEL_WIDGETS:
        log("[hf]    {:<18} {:<10} {}".format(widget_name, widget_type, purpose))


main()

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HFAlignmentPanel.generated.h"

class UTextBlock;
class USlider;
class UButton;
class UCheckBox;
class UCheckBox;
class AHFTrackingOrigin;
class AHFTrackedCamera;
class AHFLidarAnchor;

/**
 * Behaviour for WBP_AlignmentPanel. All the wiring lives here so the Widget
 * Blueprint only has to supply layout.
 *
 * Every binding is BindWidgetOptional on purpose: a panel that is missing the
 * scale slider should still compile and run, rather than failing the whole
 * widget the way BindWidget would. Name a widget in the WBP to match a property
 * below and it wires itself up.
 */
UCLASS(Abstract, Blueprintable)
class HYPERFUSIONVP_API UHFAlignmentPanel : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	// ── Readouts ────────────────────────────────────────────────────────────
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> StatusText;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> FpsText;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> MarkerText;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> GpuReminderText;

	// ── Overlay controls ────────────────────────────────────────────────────
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UCheckBox> OverlayToggle;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider>   OpacitySlider;

	// ── Alignment ───────────────────────────────────────────────────────────
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UButton> StorePoseButton;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UButton> ResetPoseButton;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UButton> AnchorLidarButton;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> LidarStatusText;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> LidarFitnessText;

	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderX;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderY;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderZ;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderRoll;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderPitch;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderYaw;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<USlider> SliderScale;

	/** Sliders run 0..1; this is the +/- travel each translation slider maps to, in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Alignment",
	          meta = (ClampMin = "1.0"))
	float TranslationRangeCm = 200.0f;

	/** +/- travel for the rotation sliders, in degrees. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Alignment",
	          meta = (ClampMin = "1.0", ClampMax = "180.0"))
	float RotationRangeDeg = 180.0f;

	/** Recentres every slider without sending a command. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Alignment")
	void ResetSlidersToNeutral();

protected:
	UFUNCTION() void HandleStatus(FString Status, float FpsIn, float FpsOut, int32 GateRejects);
	UFUNCTION() void HandleMarker(int32 MarkerID, FVector Position);

	UFUNCTION() void HandleStorePose();
	UFUNCTION() void HandleResetPose();
	UFUNCTION() void HandleAnchorLidar();
	UFUNCTION() void HandleLidarStatus(bool bAligned, float Fitness, float CorrectionMm);
	UFUNCTION() void HandleCameraSnap(FVector Position, FRotator Rotation);
	UFUNCTION() void HandleOverlayToggled(bool bChecked);
	UFUNCTION() void HandleOpacityChanged(float Value);
	UFUNCTION() void HandleOffsetSliderChanged(float Value);

private:
	TWeakObjectPtr<AHFTrackingOrigin> Origin;
	TWeakObjectPtr<AHFTrackedCamera>  TrackedCamera;
	TWeakObjectPtr<AHFLidarAnchor> LidarAnchor;

	/** Slider 0..1 -> symmetric range centred on zero. */
	static float SliderToSigned(const USlider* Slider, float Range);

	void PushOffset();
	void CacheActors();
};

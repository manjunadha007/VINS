#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "HAL/ThreadSafeBool.h"
#include "HFCommandChannel.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FOnStatusReceived, FString, Status, float, FpsIn, float, FpsOut, int32, GateRejects);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMarkerDetected, int32, MarkerID, FVector, Position);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnLidarStatus, bool, bAligned, float, Fitness, float, CorrectionMm);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnCameraSnap, FVector, Position, FRotator, Rotation);

/**
 * Handles bidirectional JSON/UDP communication with the HyperFusion headless bridge.
 * Sends alignment commands and receives tracking status/ArUco detections.
 */
UCLASS(ClassGroup=(HyperFusion), meta=(BlueprintSpawnableComponent))
class HYPERFUSIONVP_API UHFCommandChannel : public UActorComponent
{
	GENERATED_BODY()

public:
	UHFCommandChannel();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
	                           FActorComponentTickFunction* ThisTickFunction) override;

	/** Bridge IP Address (usually 127.0.0.1 if running on same machine) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Command")
	FString BridgeIP = TEXT("127.0.0.1");

	/** Port to send commands to the bridge */
	UPROPERTY(EditAnywhere, Category = "HyperFusion|Command")
	int32 CommandPort = 11114;

	/** Port to receive status from the bridge */
	UPROPERTY(EditAnywhere, Category = "HyperFusion|Command")
	int32 StatusPort = 11113;

	// -- Blueprint Events ----------------------------------------------------

	/** Fired when status is updated (usually every 500ms) */
	UPROPERTY(BlueprintAssignable, Category = "HyperFusion|Command")
	FOnStatusReceived OnStatusReceived;

	/** Fired when the bridge detects an ArUco marker */
	UPROPERTY(BlueprintAssignable, Category = "HyperFusion|Command")
	FOnMarkerDetected OnMarkerDetected;

	/** Fired when LiDAR ICP status arrives from the bridge */
	UPROPERTY(BlueprintAssignable, Category = "HyperFusion|Command")
	FOnLidarStatus OnLidarStatus;

	/** Fired once after anchoring — Unreal should teleport the CineCamera here */
	UPROPERTY(BlueprintAssignable, Category = "HyperFusion|Command")
	FOnCameraSnap OnCameraSnap;


	// -- Blueprint Callable Commands -----------------------------------------

	/** Lock the current alignment */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Command")
	void SendStorePose();

	/** Clear the alignment */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Command")
	void SendResetPose();

	/** Request ArUco zeroing */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Command")
	void SendAnchorAruco();

	/** Send anchor + LiDAR alignment command to bridge */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Command")
	void SendAnchorLidar(FVector MarkerMapPosition, FRotator MarkerMapRotation, FString MapFilePath);

	/** Apply manual translation/rotation offset */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Command")
	void SendOffset(FVector Translation, FRotator Rotation, float Scale);

private:
	// Background status receiver thread
	class FStatusRunnable : public FRunnable
	{
	public:
		FStatusRunnable(UHFCommandChannel* InOwner);
		virtual bool Init() override;
		virtual uint32 Run() override;
		virtual void Stop() override;

	private:
		UHFCommandChannel* Owner;
		FThreadSafeBool bShouldStop;
	};

	FStatusRunnable* Runnable = nullptr;
	FRunnableThread* StatusThread = nullptr;

	class FSocket* CommandSocket = nullptr;

	// Thread-safe status handoff
	FCriticalSection StatusLock;
	FString PendingStatusJson;
	FThreadSafeBool bNewStatusReady;

	void ProcessPendingStatus();
	void SendJson(const FString& JsonStr);
};

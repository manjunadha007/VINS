#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Engine/Texture2D.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "HAL/ThreadSafeBool.h"
#include "HFVideoReceiver.generated.h"

/**
 * Receives JPEG camera frames from the HyperFusion headless bridge over UDP
 * and renders them as a UTexture2D that can be applied to any material.
 *
 * Protocol: Each UDP datagram contains a 4-byte big-endian length header
 * followed by the JPEG payload. The bridge sends ~30 fps from the RealSense
 * 640x480 infrared stream.
 */
UCLASS(ClassGroup=(HyperFusion), meta=(BlueprintSpawnableComponent))
class HYPERFUSIONVP_API UHFVideoReceiver : public UActorComponent
{
	GENERATED_BODY()

public:
	UHFVideoReceiver();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
	                           FActorComponentTickFunction* ThisTickFunction) override;

	/** The live camera texture. Bind this to a material parameter. */
	UPROPERTY(BlueprintReadOnly, Category = "HyperFusion|Video")
	TObjectPtr<UTexture2D> VideoTexture;

	/** Overlay opacity (0.0 = invisible, 1.0 = fully opaque). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Video",
	          meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float Opacity = 0.5f;

	/** Toggle overlay visibility. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Video")
	bool bShowOverlay = true;

	/** UDP port to listen on for JPEG frames. */
	UPROPERTY(EditAnywhere, Category = "HyperFusion|Video")
	int32 ListenPort = 11112;

	/** Set overlay opacity from Blueprint. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Video")
	void SetOpacity(float NewOpacity);

	/** Toggle overlay visibility from Blueprint. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Video")
	void SetOverlayVisible(bool bVisible);

	/** Returns true if we have received at least one frame. */
	UFUNCTION(BlueprintPure, Category = "HyperFusion|Video")
	bool HasVideoSignal() const { return bHasReceivedFrame; }

	/** Frames decoded per second, averaged over the last second. */
	UFUNCTION(BlueprintPure, Category = "HyperFusion|Video")
	float GetVideoFps() const { return VideoFps; }

private:
	// Background receiver thread
	class FReceiverRunnable : public FRunnable
	{
	public:
		explicit FReceiverRunnable(UHFVideoReceiver* InOwner);
		virtual bool Init() override;
		virtual uint32 Run() override;
		virtual void Stop() override;

	private:
		UHFVideoReceiver* Owner;
		FThreadSafeBool bShouldStop;
	};

	FReceiverRunnable* Runnable = nullptr;
	FRunnableThread* ReceiverThread = nullptr;

	// Hand-off between the network thread (producer) and the game thread (consumer).
	// PendingFrameData is decoded BGRA8, not the JPEG bytes: decoding happens on the
	// network thread so the game thread only pays for the texture upload.
	FCriticalSection FrameLock;
	TArray64<uint8> PendingFrameData;
	int32 PendingWidth = 0;
	int32 PendingHeight = 0;
	FThreadSafeBool bNewFrameReady;
	FThreadSafeBool bHasReceivedFrame;

	// FPS accounting (game thread only)
	float VideoFps = 0.0f;
	int32 FramesThisSecond = 0;
	float FpsAccumulator = 0.0f;

	void ProcessPendingFrame();
	void CreateOrResizeTexture(int32 Width, int32 Height);
};

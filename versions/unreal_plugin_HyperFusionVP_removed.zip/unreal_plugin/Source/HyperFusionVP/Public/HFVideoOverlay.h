#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HFVideoOverlay.generated.h"

class UHFVideoReceiver;
class UImage;
class UScaleBox;

/** How the feed is fitted into the viewport. */
UENUM(BlueprintType)
enum class EHFOverlayFit : uint8
{
	/** Span the full window width, letterboxed top and bottom. Aspect preserved. */
	FitWidth  UMETA(DisplayName = "Fit Width"),
	/** Span the full window height, pillarboxed left and right. Aspect preserved. */
	FitHeight UMETA(DisplayName = "Fit Height"),
	/** Largest size that fits entirely on screen. Aspect preserved. */
	Fit       UMETA(DisplayName = "Fit Inside"),
	/** Cover the whole window, cropping the overflow. Aspect preserved. */
	Fill      UMETA(DisplayName = "Fill (crop)"),
	/** Stretch to the window exactly. Aspect NOT preserved. */
	Stretch   UMETA(DisplayName = "Stretch (distorts)")
};

/**
 * Draws the bridge camera feed across the whole viewport.
 *
 * Unlike the world-space quad on AHFTrackedCamera, this is screen space: it fills
 * the 3D window regardless of focal length, filmback, or which camera you happen
 * to be looking through. That makes it the useful thing for eyeballing whether
 * the CG lines up with the plate.
 *
 * The widget tree is built in C++, so there is no Widget Blueprint to lay out.
 * Visibility and opacity are read from the UHFVideoReceiver, which means the
 * existing panel toggle and opacity slider drive it with no extra wiring.
 *
 * Appears in PIE / the game viewport. An editor viewport with nothing playing has
 * no widget layer to draw into, and the receiver is not running there anyway.
 */
UCLASS(Blueprintable, ClassGroup=(HyperFusion))
class HYPERFUSIONVP_API UHFVideoOverlay : public UUserWidget
{
	GENERATED_BODY()

public:
	UHFVideoOverlay(const FObjectInitializer& ObjectInitializer);

	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	/** Where the pixels come from. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Overlay")
	void SetReceiver(UHFVideoReceiver* InReceiver);

	/** How the feed is fitted to the window. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	EHFOverlayFit Fit = EHFOverlayFit::FitWidth;

	/**
	 * Extra multiplier on the fitted size. 1.0 fills the window exactly per Fit;
	 * drop below 1 to inset the plate inside the frame.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay",
	          meta = (ClampMin = "0.05", ClampMax = "1.0"))
	float FitScale = 1.0f;

protected:
	UPROPERTY(Transient)
	TObjectPtr<UImage> VideoImage;

	UPROPERTY(Transient)
	TObjectPtr<UScaleBox> ScaleBoxRoot;

	TWeakObjectPtr<UHFVideoReceiver> Receiver;

private:
	/** Cached so the brush is only rebuilt when the texture object actually changes. */
	TWeakObjectPtr<UTexture2D> LastTexture;
};

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FHyperFusionVPModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	/** Applies the t.MaxFPS cap once the engine exists. */
	void ApplyFrameRateCap();

	FDelegateHandle PostEngineInitHandle;
};

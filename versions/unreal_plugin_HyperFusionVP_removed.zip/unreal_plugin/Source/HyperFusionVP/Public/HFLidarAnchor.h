#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HFLidarAnchor.generated.h"

/**
 * Marks where a physical ArUco marker sits in the LiDAR-scanned environment.
 * Place this actor at the marker's real-world position on the imported scan.
 * 
 * When the operator triggers "Anchor + Align LiDAR", this actor's world
 * transform is sent to the bridge as the marker's position in map space,
 * allowing the bridge to compute the SLAM-to-map coordinate transform.
 */
UCLASS(Blueprintable, ClassGroup=(HyperFusion))
class HYPERFUSIONVP_API AHFLidarAnchor : public AActor
{
    GENERATED_BODY()

public:
    AHFLidarAnchor();

    /** Which ArUco marker ID this anchor corresponds to. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|LiDAR")
    int32 MarkerID = 0;

    /** Size of the physical marker in cm (for visual gizmo scaling). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|LiDAR")
    float MarkerSizeCm = 10.0f;

    /** Path to the LiDAR point cloud file (.ply or .pcd) on the bridge machine. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|LiDAR")
    FString LidarMapPath;

    /** Visual indicator showing alignment quality. Updated by status stream. */
    UPROPERTY(BlueprintReadOnly, Transient, Category = "HyperFusion|LiDAR")
    float AlignmentQuality = 0.0f;

    /** True once the bridge confirms initial ICP alignment succeeded. */
    UPROPERTY(BlueprintReadOnly, Transient, Category = "HyperFusion|LiDAR")
    bool bIsAligned = false;

    /** Get the marker's world transform in metres (for sending to bridge). */
    UFUNCTION(BlueprintCallable, Category = "HyperFusion|LiDAR")
    FTransform GetMarkerMapTransform() const;

    /** Find the first LiDAR anchor in the world. */
    UFUNCTION(BlueprintCallable, Category = "HyperFusion|LiDAR",
              meta = (WorldContext = "WorldContextObject"))
    static AHFLidarAnchor* Get(const UObject* WorldContextObject);

private:
    /** Visual representation in the editor (a flat plane with the ArUco pattern). */
    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UStaticMeshComponent> MarkerMesh;
};

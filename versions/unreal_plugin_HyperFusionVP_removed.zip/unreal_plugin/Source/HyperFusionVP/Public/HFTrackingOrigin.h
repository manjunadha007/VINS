#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HFTrackingOrigin.generated.h"

class UHFCommandChannel;

/**
 * The real-world origin. Drag this actor in the viewport to align the virtual
 * world with the physical space; every tracked camera is parented beneath it, so
 * moving the origin moves the whole tracked rig without touching the pose stream.
 *
 * Owns the single UHFCommandChannel that talks to the bridge. BP_TrackingOrigin
 * is a Blueprint subclass of this and needs no graph of its own.
 */
UCLASS(Blueprintable, ClassGroup=(HyperFusion))
class HYPERFUSIONVP_API AHFTrackingOrigin : public AActor
{
	GENERATED_BODY()

public:
	AHFTrackingOrigin();

	/** Bidirectional UDP link to bridge_headless.py. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HyperFusion")
	TObjectPtr<UHFCommandChannel> CommandChannel;

	/**
	 * Push this actor's current transform to the bridge as the alignment offset,
	 * so the correction is applied upstream of Unreal rather than re-applied to
	 * every incoming pose here.
	 */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "HyperFusion")
	void PushTransformAsOffset();

	/** Convenience passthroughs so the panel can talk to one object. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion")
	void StorePose();

	UFUNCTION(BlueprintCallable, Category = "HyperFusion")
	void ResetPose();

	/** Finds the origin actor in the world, or nullptr if the level has none. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion", meta = (WorldContext = "WorldContextObject"))
	static AHFTrackingOrigin* Get(const UObject* WorldContextObject);
};

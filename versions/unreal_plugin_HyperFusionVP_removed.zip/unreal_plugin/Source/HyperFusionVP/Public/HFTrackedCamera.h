#pragma once

#include "CoreMinimal.h"
#include "CineCameraActor.h"
#include "LiveLinkTypes.h"
#include "HFTrackedCamera.generated.h"

class UHFVideoReceiver;
class UHFVideoOverlay;
class ULiveLinkComponentController;
class UStaticMeshComponent;
class UMaterialInterface;
class UMaterialInstanceDynamic;

/** Where the camera feed is drawn. */
UENUM(BlueprintType)
enum class EHFOverlayMode : uint8
{
	/** Full-viewport UMG layer. Fills the 3D window whatever the camera is doing. */
	ScreenSpace UMETA(DisplayName = "Screen Space (fills viewport)"),
	/** Quad in front of the lens. Only fills frame when looking through this camera. */
	WorldQuad   UMETA(DisplayName = "World Quad (in front of lens)"),
	/** No overlay. */
	None        UMETA(DisplayName = "Off")
};

/**
 * A CineCamera driven by the LiveLink FreeD source, with the RealSense feed
 * composited in front of the lens.
 *
 * The overlay is a plane parented to the camera and rescaled every frame to
 * exactly fill the current field of view, so it stays registered with the 3D
 * scene when focal length changes. BP_TrackedCamera is a Blueprint subclass of
 * this; the only thing it must supply is OverlayMaterial.
 */
UCLASS(Blueprintable, ClassGroup=(HyperFusion))
class HYPERFUSIONVP_API AHFTrackedCamera : public ACineCameraActor
{
	GENERATED_BODY()

public:
	// ACineCameraActor has no default constructor: it builds its camera component
	// through the initializer, so we have to thread it through.
	AHFTrackedCamera(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;

	/** Screen space by default: it fills the viewport regardless of lens or view. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	EHFOverlayMode OverlayMode = EHFOverlayMode::ScreenSpace;

	/** Widget class used for the screen-space overlay. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	TSubclassOf<UHFVideoOverlay> ScreenOverlayClass;

	/** Negative keeps the plate under the alignment panel, which adds at 0. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	int32 ScreenOverlayZOrder = -10;

	/** The live screen-space overlay, once created. */
	UPROPERTY(BlueprintReadOnly, Transient, Category = "HyperFusion|Overlay")
	TObjectPtr<UHFVideoOverlay> ScreenOverlay;

	/** Receives JPEG frames from the bridge on UDP 11112. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HyperFusion")
	TObjectPtr<UHFVideoReceiver> VideoReceiver;

	/**
	 * Drives this camera's transform from a LiveLink subject. The video path
	 * (UDP 11112) carries no pose, so without this the camera never moves however
	 * healthy the bridge is.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HyperFusion|LiveLink")
	TObjectPtr<ULiveLinkComponentController> LiveLinkController;

	/**
	 * Name of the FreeD subject to follow, as it appears in the Live Link panel.
	 * Leave empty to configure the controller by hand instead.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|LiveLink")
	FLiveLinkSubjectName LiveLinkSubject;

	/**
	 * Make this camera the view target on Play.
	 *
	 * The project's default GameMode spawns a pawn and views through it, so
	 * without this Play lands in the ThirdPerson character rather than the
	 * tracked camera.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|LiveLink")
	bool bTakeViewOnPlay = true;

	/** The quad the camera feed is drawn on. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "HyperFusion")
	TObjectPtr<UStaticMeshComponent> OverlayPlane;

	/**
	 * Translucent unlit material with a "VideoTexture" texture parameter and an
	 * "Opacity" scalar parameter. Assign M_CameraOverlay here.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	TObjectPtr<UMaterialInterface> OverlayMaterial;

	/** How far in front of the lens the overlay sits, in cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay",
	          meta = (ClampMin = "10.0"))
	float OverlayDistance = 150.0f;

	/** Rotate the quad if the feed comes through mirrored or upside down. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HyperFusion|Overlay")
	float OverlayRoll = 0.0f;

	/** Toggle the overlay (bound to the V hotkey in BP_TrackedCamera). */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Overlay")
	void ToggleOverlay();

	/** 0..1, forwarded to the video receiver and the material. */
	UFUNCTION(BlueprintCallable, Category = "HyperFusion|Overlay")
	void SetOverlayOpacity(float NewOpacity);

private:
	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> OverlayMID;

	void FitOverlayToFrustum();
};

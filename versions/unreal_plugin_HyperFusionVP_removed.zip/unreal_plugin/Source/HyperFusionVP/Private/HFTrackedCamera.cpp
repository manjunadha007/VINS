#include "HFTrackedCamera.h"
#include "HFVideoReceiver.h"
#include "HFVideoOverlay.h"
#include "Blueprint/UserWidget.h"
#include "CineCameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"
#include "LiveLinkComponentController.h"
#include "Roles/LiveLinkCameraRole.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"

// Parameter names the overlay material must expose. The Python content
// generator (Tools/hf_build_content.py) creates M_CameraOverlay with exactly
// these, so renaming one here means renaming it there too.
static const FName HF_PARAM_TEXTURE(TEXT("VideoTexture"));
static const FName HF_PARAM_OPACITY(TEXT("Opacity"));

// /Engine/BasicShapes/Plane is 100x100 uu at unit scale.
static constexpr float HF_PLANE_BASE_SIZE = 100.0f;

AHFTrackedCamera::AHFTrackedCamera(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	VideoReceiver = CreateDefaultSubobject<UHFVideoReceiver>(TEXT("VideoReceiver"));
	LiveLinkController = CreateDefaultSubobject<ULiveLinkComponentController>(TEXT("LiveLinkController"));

	OverlayPlane = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("OverlayPlane"));
	OverlayPlane->SetupAttachment(GetCineCameraComponent());

	// Pitch +90 takes the plane's +Z normal round to -X, i.e. facing back down
	// the lens axis at the camera.
	OverlayPlane->SetRelativeRotation(FRotator(90.0f, 0.0f, 0.0f));
	OverlayPlane->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	OverlayPlane->SetCastShadow(false);
	OverlayPlane->bReceivesDecals = false;
	OverlayPlane->SetHiddenInGame(false);

	static ConstructorHelpers::FObjectFinder<UStaticMesh> PlaneMesh(TEXT("/Engine/BasicShapes/Plane.Plane"));
	if (PlaneMesh.Succeeded())
	{
		OverlayPlane->SetStaticMesh(PlaneMesh.Object);
	}

	ScreenOverlayClass = UHFVideoOverlay::StaticClass();
}

void AHFTrackedCamera::BeginPlay()
{
	Super::BeginPlay();

	// The quad is only ever needed in WorldQuad mode; leave it off otherwise so it
	// cannot park an untextured plane in front of the lens.
	OverlayPlane->SetVisibility(false);

	if (LiveLinkController && !LiveLinkSubject.Name.IsNone())
	{
		FLiveLinkSubjectRepresentation Representation;
		Representation.Subject = LiveLinkSubject;
		Representation.Role = ULiveLinkCameraRole::StaticClass();
		LiveLinkController->SetSubjectRepresentation(Representation);

		UE_LOG(LogTemp, Log, TEXT("[HFTrackedCamera] Following LiveLink subject '%s'."),
		       *LiveLinkSubject.Name.ToString());
	}
	else if (LiveLinkController && LiveLinkController->GetSubjectRepresentation().Subject.Name.IsNone())
	{
		// Only complain when nothing is driving the controller at all: setting the
		// subject on the component directly in the Details panel is a perfectly
		// good alternative to filling in LiveLinkSubject.
		UE_LOG(LogTemp, Warning,
		       TEXT("[HFTrackedCamera] No LiveLink subject on either LiveLinkSubject or the "
		            "controller — the camera will not move. Add a FreeD source on port 11111 "
		            "in the Live Link panel, then name its subject."));
	}

	if (bTakeViewOnPlay)
	{
		// The default GameMode spawns a pawn and views through it, so claim the
		// view explicitly rather than relying on auto-activation.
		if (APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0))
		{
			PC->SetViewTarget(this);
		}
	}

	if (OverlayMode == EHFOverlayMode::WorldQuad)
	{
		if (OverlayMaterial)
		{
			OverlayMID = UMaterialInstanceDynamic::Create(OverlayMaterial, this);
			OverlayPlane->SetMaterial(0, OverlayMID);
		}
		else
		{
			UE_LOG(LogTemp, Warning,
			       TEXT("[HFTrackedCamera] OverlayMode is WorldQuad but no OverlayMaterial is "
			            "assigned — the feed will not be visible. Assign M_CameraOverlay."));
		}
	}
	else if (OverlayMode == EHFOverlayMode::ScreenSpace)
	{
		if (!ScreenOverlayClass)
		{
			ScreenOverlayClass = UHFVideoOverlay::StaticClass();
		}

		ScreenOverlay = CreateWidget<UHFVideoOverlay>(GetWorld(), ScreenOverlayClass);
		if (ScreenOverlay)
		{
			ScreenOverlay->SetReceiver(VideoReceiver);
			ScreenOverlay->AddToViewport(ScreenOverlayZOrder);
			UE_LOG(LogTemp, Log, TEXT("[HFTrackedCamera] Screen-space overlay added (ZOrder %d)."),
			       ScreenOverlayZOrder);
		}
		else
		{
			UE_LOG(LogTemp, Warning,
			       TEXT("[HFTrackedCamera] Could not create the screen-space overlay widget."));
		}
	}
}

void AHFTrackedCamera::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (ScreenOverlay)
	{
		ScreenOverlay->RemoveFromParent();
		ScreenOverlay = nullptr;
	}

	Super::EndPlay(EndPlayReason);
}

void AHFTrackedCamera::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// The screen-space overlay drives itself from the receiver in its own tick;
	// only the world quad needs per-frame work from the actor.
	if (OverlayMode != EHFOverlayMode::WorldQuad || !VideoReceiver || !OverlayPlane)
	{
		return;
	}

	// Nothing to show until the first frame lands; an untextured quad parked in
	// front of the lens would otherwise black out the shot.
	const bool bVisible = VideoReceiver->bShowOverlay && VideoReceiver->HasVideoSignal();
	if (OverlayPlane->IsVisible() != bVisible)
	{
		OverlayPlane->SetVisibility(bVisible);
	}

	if (!bVisible || !OverlayMID)
	{
		return;
	}

	if (VideoReceiver->VideoTexture)
	{
		OverlayMID->SetTextureParameterValue(HF_PARAM_TEXTURE, VideoReceiver->VideoTexture);
	}
	OverlayMID->SetScalarParameterValue(HF_PARAM_OPACITY, VideoReceiver->Opacity);

	FitOverlayToFrustum();
}

void AHFTrackedCamera::FitOverlayToFrustum()
{
	UCineCameraComponent* Cam = GetCineCameraComponent();
	if (!Cam)
	{
		return;
	}

	const float HorizontalFOV = Cam->FieldOfView;
	if (HorizontalFOV <= 0.0f || HorizontalFOV >= 180.0f)
	{
		return;
	}

	// Width the frustum spans at OverlayDistance, then height from the sensor
	// aspect rather than the viewport's, so the feed stays 1:1 with the shot.
	const float Width = 2.0f * OverlayDistance * FMath::Tan(FMath::DegreesToRadians(HorizontalFOV * 0.5f));
	const float Aspect = Cam->AspectRatio > KINDA_SMALL_NUMBER ? Cam->AspectRatio : (16.0f / 9.0f);
	const float Height = Width / Aspect;

	OverlayPlane->SetRelativeLocation(FVector(OverlayDistance, 0.0f, 0.0f));
	OverlayPlane->SetRelativeRotation(FRotator(90.0f, 0.0f, OverlayRoll));

	// After the pitch the plane's local X runs vertically and local Y horizontally.
	OverlayPlane->SetRelativeScale3D(FVector(Height / HF_PLANE_BASE_SIZE,
	                                         Width / HF_PLANE_BASE_SIZE,
	                                         1.0f));
}

void AHFTrackedCamera::ToggleOverlay()
{
	if (VideoReceiver)
	{
		VideoReceiver->SetOverlayVisible(!VideoReceiver->bShowOverlay);
	}
}

void AHFTrackedCamera::SetOverlayOpacity(float NewOpacity)
{
	if (VideoReceiver)
	{
		VideoReceiver->SetOpacity(NewOpacity);
	}
	if (OverlayMID)
	{
		OverlayMID->SetScalarParameterValue(HF_PARAM_OPACITY, FMath::Clamp(NewOpacity, 0.0f, 1.0f));
	}
}

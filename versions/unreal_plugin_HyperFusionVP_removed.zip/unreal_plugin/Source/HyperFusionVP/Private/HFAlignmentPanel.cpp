#include "HFAlignmentPanel.h"
#include "HFTrackingOrigin.h"
#include "HFTrackedCamera.h"
#include "HFLidarAnchor.h"
#include "HFCommandChannel.h"
#include "HFVideoReceiver.h"
#include "Components/TextBlock.h"
#include "Components/Slider.h"
#include "Components/Button.h"
#include "Components/CheckBox.h"
#include "Engine/World.h"
#include "EngineUtils.h"

void UHFAlignmentPanel::NativeConstruct()
{
	Super::NativeConstruct();

	CacheActors();

	if (Origin.IsValid() && Origin->CommandChannel)
	{
		Origin->CommandChannel->OnStatusReceived.AddDynamic(this, &UHFAlignmentPanel::HandleStatus);
		Origin->CommandChannel->OnMarkerDetected.AddDynamic(this, &UHFAlignmentPanel::HandleMarker);
		Origin->CommandChannel->OnLidarStatus.AddDynamic(this, &UHFAlignmentPanel::HandleLidarStatus);
		Origin->CommandChannel->OnCameraSnap.AddDynamic(this, &UHFAlignmentPanel::HandleCameraSnap);
	}
	else
	{
		UE_LOG(LogTemp, Warning,
		       TEXT("[HFAlignmentPanel] No AHFTrackingOrigin in the level — status and alignment "
		            "controls will be inert. Drop a BP_TrackingOrigin into the map."));
		if (StatusText)
		{
			StatusText->SetText(FText::FromString(TEXT("NO ORIGIN ACTOR")));
			StatusText->SetColorAndOpacity(FSlateColor(FLinearColor::Red));
		}
	}

	if (StorePoseButton) { StorePoseButton->OnClicked.AddDynamic(this, &UHFAlignmentPanel::HandleStorePose); }
	if (ResetPoseButton) { ResetPoseButton->OnClicked.AddDynamic(this, &UHFAlignmentPanel::HandleResetPose); }
	if (AnchorLidarButton) { AnchorLidarButton->OnClicked.AddDynamic(this, &UHFAlignmentPanel::HandleAnchorLidar); }
	if (OverlayToggle)   { OverlayToggle->OnCheckStateChanged.AddDynamic(this, &UHFAlignmentPanel::HandleOverlayToggled); }
	if (OpacitySlider)   { OpacitySlider->OnValueChanged.AddDynamic(this, &UHFAlignmentPanel::HandleOpacityChanged); }

	USlider* const OffsetSliders[] = { SliderX, SliderY, SliderZ, SliderRoll, SliderPitch, SliderYaw, SliderScale };
	for (USlider* Slider : OffsetSliders)
	{
		if (Slider)
		{
			Slider->OnValueChanged.AddDynamic(this, &UHFAlignmentPanel::HandleOffsetSliderChanged);
		}
	}

	ResetSlidersToNeutral();

	if (OverlayToggle && TrackedCamera.IsValid() && TrackedCamera->VideoReceiver)
	{
		OverlayToggle->SetIsChecked(TrackedCamera->VideoReceiver->bShowOverlay);
	}
	if (OpacitySlider && TrackedCamera.IsValid() && TrackedCamera->VideoReceiver)
	{
		OpacitySlider->SetValue(TrackedCamera->VideoReceiver->Opacity);
	}
	if (GpuReminderText)
	{
		GpuReminderText->SetText(FText::FromString(TEXT("FPS capped at 30 for tracking stability")));
	}
	if (MarkerText)
	{
		MarkerText->SetText(FText::FromString(TEXT("No marker")));
	}
	if (LidarStatusText)
	{
		LidarStatusText->SetText(
			LidarAnchor.IsValid()
				? FText::FromString(TEXT("LiDAR: Ready to align"))
				: FText::FromString(TEXT("LiDAR: No anchor in level")));
	}
}

void UHFAlignmentPanel::NativeDestruct()
{
	if (Origin.IsValid() && Origin->CommandChannel)
	{
		Origin->CommandChannel->OnStatusReceived.RemoveDynamic(this, &UHFAlignmentPanel::HandleStatus);
		Origin->CommandChannel->OnMarkerDetected.RemoveDynamic(this, &UHFAlignmentPanel::HandleMarker);
		Origin->CommandChannel->OnLidarStatus.RemoveDynamic(this, &UHFAlignmentPanel::HandleLidarStatus);
		Origin->CommandChannel->OnCameraSnap.RemoveDynamic(this, &UHFAlignmentPanel::HandleCameraSnap);
	}

	Super::NativeDestruct();
}

void UHFAlignmentPanel::CacheActors()
{
	Origin = AHFTrackingOrigin::Get(this);

	if (UWorld* World = GetWorld())
	{
		TActorIterator<AHFTrackedCamera> It(World);
		TrackedCamera = It ? *It : nullptr;
	}

	LidarAnchor = AHFLidarAnchor::Get(this);
}

// ── Status ──────────────────────────────────────────────────────────────────

void UHFAlignmentPanel::HandleStatus(FString Status, float FpsIn, float FpsOut, int32 GateRejects)
{
	if (StatusText)
	{
		StatusText->SetText(FText::FromString(Status));

		FLinearColor Colour = FLinearColor::White;
		if (Status == TEXT("TRACKING"))     { Colour = FLinearColor::Green; }
		else if (Status == TEXT("WAITING")) { Colour = FLinearColor::Yellow; }
		else if (Status == TEXT("LOST"))    { Colour = FLinearColor::Red; }
		StatusText->SetColorAndOpacity(FSlateColor(Colour));
	}

	if (FpsText)
	{
		const float VideoFps = (TrackedCamera.IsValid() && TrackedCamera->VideoReceiver)
			? TrackedCamera->VideoReceiver->GetVideoFps()
			: 0.0f;

		FpsText->SetText(FText::FromString(FString::Printf(
			TEXT("SLAM: %.1f Hz  ->  FreeD: %.1f Hz  |  video %.1f fps  |  rejects %d"),
			FpsIn, FpsOut, VideoFps, GateRejects)));
	}
}

void UHFAlignmentPanel::HandleMarker(int32 MarkerID, FVector Position)
{
	if (MarkerText)
	{
		MarkerText->SetText(FText::FromString(FString::Printf(
			TEXT("Marker #%d detected!  (%.0f, %.0f, %.0f cm)"),
			MarkerID, Position.X, Position.Y, Position.Z)));
	}
}

// ── Commands ────────────────────────────────────────────────────────────────

void UHFAlignmentPanel::HandleStorePose()
{
	if (Origin.IsValid())
	{
		Origin->StorePose();
	}
}

void UHFAlignmentPanel::HandleResetPose()
{
	if (Origin.IsValid())
	{
		Origin->ResetPose();
	}
	ResetSlidersToNeutral();
}

void UHFAlignmentPanel::HandleAnchorLidar()
{
	if (!Origin.IsValid() || !Origin->CommandChannel || !LidarAnchor.IsValid())
	{
		if (LidarStatusText)
			LidarStatusText->SetText(FText::FromString(
				TEXT("ERROR: Missing TrackingOrigin or LidarAnchor")));
		return;
	}

	FTransform MapT = LidarAnchor->GetMarkerMapTransform();
	Origin->CommandChannel->SendAnchorLidar(
		MapT.GetLocation(),
		MapT.GetRotation().Rotator(),
		LidarAnchor->LidarMapPath);

	if (LidarStatusText)
		LidarStatusText->SetText(FText::FromString(TEXT("LiDAR: Aligning...")));
}

void UHFAlignmentPanel::HandleLidarStatus(bool bAligned, float Fitness, float CorrectionMm)
{
	if (LidarAnchor.IsValid())
	{
		LidarAnchor->bIsAligned = bAligned;
		LidarAnchor->AlignmentQuality = Fitness;
	}

	if (LidarStatusText)
	{
		FString StatusStr = bAligned
			? FString::Printf(TEXT("LiDAR: ALIGNED ✓"))
			: FString::Printf(TEXT("LiDAR: NOT ALIGNED"));
		LidarStatusText->SetText(FText::FromString(StatusStr));
		LidarStatusText->SetColorAndOpacity(FSlateColor(
			bAligned ? FLinearColor::Green : FLinearColor::Yellow));
	}

	if (LidarFitnessText)
	{
		LidarFitnessText->SetText(FText::FromString(FString::Printf(
			TEXT("ICP: fitness %.2f | correction %.1f mm"), Fitness, CorrectionMm)));
	}
}

void UHFAlignmentPanel::HandleCameraSnap(FVector Position, FRotator Rotation)
{
	// Teleport the tracked camera (CineCamera) to the computed snap position.
	// This fires once after anchoring; the dashboard has computed the camera's
	// Unreal-space position from the marker + depth + SLAM data.
	if (TrackedCamera.IsValid())
	{
		TrackedCamera->SetActorLocationAndRotation(Position, Rotation, false, nullptr, ETeleportType::TeleportPhysics);
		UE_LOG(LogTemp, Log, TEXT("[HFAlignment] Camera snapped to (%.1f, %.1f, %.1f)"),
		       Position.X, Position.Y, Position.Z);
	}

	if (LidarStatusText)
	{
		LidarStatusText->SetText(FText::FromString(TEXT("SNAPPED ✓ — Tracking live")));
		LidarStatusText->SetColorAndOpacity(FSlateColor(FLinearColor::Green));
	}
}

void UHFAlignmentPanel::HandleOverlayToggled(bool bChecked)
{
	if (TrackedCamera.IsValid() && TrackedCamera->VideoReceiver)
	{
		TrackedCamera->VideoReceiver->SetOverlayVisible(bChecked);
	}
}

void UHFAlignmentPanel::HandleOpacityChanged(float Value)
{
	if (TrackedCamera.IsValid())
	{
		TrackedCamera->SetOverlayOpacity(Value);
	}
}

void UHFAlignmentPanel::HandleOffsetSliderChanged(float Value)
{
	PushOffset();
}

// ── Alignment plumbing ──────────────────────────────────────────────────────

float UHFAlignmentPanel::SliderToSigned(const USlider* Slider, float Range)
{
	// Absent slider reads as centred, so a partial panel still sends a coherent
	// offset for the axes it does expose.
	if (!Slider)
	{
		return 0.0f;
	}
	return (Slider->GetValue() - 0.5f) * 2.0f * Range;
}

void UHFAlignmentPanel::PushOffset()
{
	if (!Origin.IsValid() || !Origin->CommandChannel)
	{
		return;
	}

	const FVector Translation(
		SliderToSigned(SliderX, TranslationRangeCm),
		SliderToSigned(SliderY, TranslationRangeCm),
		SliderToSigned(SliderZ, TranslationRangeCm));

	const FRotator Rotation(
		SliderToSigned(SliderPitch, RotationRangeDeg),
		SliderToSigned(SliderYaw,   RotationRangeDeg),
		SliderToSigned(SliderRoll,  RotationRangeDeg));

	// Scale slider maps 0..1 onto 0.5x..1.5x; neutral sits at the midpoint like
	// every other slider so "all centred" means "identity transform".
	const float Scale = SliderScale ? (0.5f + SliderScale->GetValue()) : 1.0f;

	Origin->CommandChannel->SendOffset(Translation, Rotation, Scale);
}

void UHFAlignmentPanel::ResetSlidersToNeutral()
{
	USlider* const OffsetSliders[] = { SliderX, SliderY, SliderZ, SliderRoll, SliderPitch, SliderYaw, SliderScale };
	for (USlider* Slider : OffsetSliders)
	{
		if (Slider)
		{
			Slider->SetValue(0.5f);
		}
	}
}

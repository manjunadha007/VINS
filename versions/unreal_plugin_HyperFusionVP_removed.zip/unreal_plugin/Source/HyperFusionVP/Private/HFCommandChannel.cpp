#include "HFCommandChannel.h"
#include "Common/UdpSocketBuilder.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "Interfaces/IPv4/IPv4Address.h"

UHFCommandChannel::UHFCommandChannel()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PrePhysics;
}

void UHFCommandChannel::BeginPlay()
{
	Super::BeginPlay();

	// Create UDP socket for sending commands
	CommandSocket = FUdpSocketBuilder(TEXT("HFCommandSocket"))
		.AsNonBlocking()
		.AsReusable();

	// Start background thread for receiving status
	Runnable = new FStatusRunnable(this);
	StatusThread = FRunnableThread::Create(Runnable, TEXT("HFStatusThread"), 0, TPri_BelowNormal);
}

void UHFCommandChannel::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (Runnable)
	{
		Runnable->Stop();
		if (StatusThread)
		{
			StatusThread->WaitForCompletion();
			delete StatusThread;
			StatusThread = nullptr;
		}
		delete Runnable;
		Runnable = nullptr;
	}

	if (CommandSocket)
	{
		CommandSocket->Close();
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(CommandSocket);
		CommandSocket = nullptr;
	}

	Super::EndPlay(EndPlayReason);
}

void UHFCommandChannel::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bNewStatusReady)
	{
		ProcessPendingStatus();
	}
}

void UHFCommandChannel::ProcessPendingStatus()
{
	FString JsonStr;
	{
		FScopeLock Lock(&StatusLock);
		if (!bNewStatusReady) return;
		JsonStr = PendingStatusJson;
		bNewStatusReady = false;
	}

	TSharedPtr<FJsonObject> JsonObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(JsonStr);
	if (!FJsonSerializer::Deserialize(Reader, JsonObj) || !JsonObj.IsValid())
	{
		return;
	}

	// Every field is read with TryGet: a malformed or partial datagram must not
	// take the editor down, and GetStringField/GetNumberField assert on a miss.
	FString Status;
	JsonObj->TryGetStringField(TEXT("status"), Status);

	double FpsIn = 0.0;
	double FpsOut = 0.0;
	int32 GateRejects = 0;
	JsonObj->TryGetNumberField(TEXT("fps_in"), FpsIn);
	JsonObj->TryGetNumberField(TEXT("fps_out"), FpsOut);
	JsonObj->TryGetNumberField(TEXT("gate_rejects"), GateRejects);

	OnStatusReceived.Broadcast(Status, static_cast<float>(FpsIn), static_cast<float>(FpsOut), GateRejects);

	// Parse ArUco (optional — the bridge omits "marker" entirely when it has none)
	const TSharedPtr<FJsonObject>* MarkerObj = nullptr;
	if (JsonObj->TryGetObjectField(TEXT("marker"), MarkerObj) && MarkerObj && MarkerObj->IsValid())
	{
		int32 MarkerID = 0;
		(*MarkerObj)->TryGetNumberField(TEXT("id"), MarkerID);

		const TArray<TSharedPtr<FJsonValue>>* TvecArray = nullptr;
		if ((*MarkerObj)->TryGetArrayField(TEXT("tvec"), TvecArray) && TvecArray && TvecArray->Num() >= 3)
		{
			// tvec is in meters, Unreal is in cm
			const FVector Position(
				(*TvecArray)[0]->AsNumber() * 100.0,
				(*TvecArray)[1]->AsNumber() * 100.0,
				(*TvecArray)[2]->AsNumber() * 100.0
			);
			OnMarkerDetected.Broadcast(MarkerID, Position);
		}
	}

	// Parse LiDAR diagnostics (optional — bridge omits when LiDAR is disabled)
	const TSharedPtr<FJsonObject>* LidarObj = nullptr;
	if (JsonObj->TryGetObjectField(TEXT("lidar"), LidarObj) && LidarObj && LidarObj->IsValid())
	{
		bool bAligned = false;
		(*LidarObj)->TryGetBoolField(TEXT("lidar_aligned"), bAligned);

		double Fitness = 0.0, CorrectionMm = 0.0;
		(*LidarObj)->TryGetNumberField(TEXT("icp_fitness"), Fitness);
		(*LidarObj)->TryGetNumberField(TEXT("correction_mm"), CorrectionMm);

		OnLidarStatus.Broadcast(bAligned,
								static_cast<float>(Fitness),
								static_cast<float>(CorrectionMm));
	}

	// Parse snap_camera (one-shot: dashboard sends exactly once after anchoring)
	const TSharedPtr<FJsonObject>* SnapObj = nullptr;
	if (JsonObj->TryGetObjectField(TEXT("snap_camera"), SnapObj) && SnapObj && SnapObj->IsValid())
	{
		const TSharedPtr<FJsonObject>* PosObj = nullptr;
		const TSharedPtr<FJsonObject>* RotObj = nullptr;
		if ((*SnapObj)->TryGetObjectField(TEXT("position"), PosObj) && PosObj && PosObj->IsValid()
			&& (*SnapObj)->TryGetObjectField(TEXT("rotation"), RotObj) && RotObj && RotObj->IsValid())
		{
			double X = 0, Y = 0, Z = 0;
			(*PosObj)->TryGetNumberField(TEXT("x"), X);
			(*PosObj)->TryGetNumberField(TEXT("y"), Y);
			(*PosObj)->TryGetNumberField(TEXT("z"), Z);
			// Position arrives in metres; Unreal uses centimetres
			const FVector SnapPos(X * 100.0, Y * 100.0, Z * 100.0);

			double Pan = 0, Tilt = 0, Roll = 0;
			(*RotObj)->TryGetNumberField(TEXT("pan"), Pan);
			(*RotObj)->TryGetNumberField(TEXT("tilt"), Tilt);
			(*RotObj)->TryGetNumberField(TEXT("roll"), Roll);
			const FRotator SnapRot(Tilt, Pan, Roll);

			OnCameraSnap.Broadcast(SnapPos, SnapRot);
			UE_LOG(LogTemp, Log, TEXT("[HFCommand] snap_camera: X=%.1f Y=%.1f Z=%.1f"), SnapPos.X, SnapPos.Y, SnapPos.Z);
		}
	}
}

void UHFCommandChannel::SendJson(const FString& JsonStr)
{
	if (!CommandSocket) return;

	FIPv4Address IP;
	FIPv4Address::Parse(BridgeIP, IP);
	TSharedRef<FInternetAddr> Addr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
	Addr->SetIp(IP.Value);
	Addr->SetPort(CommandPort);

	FTCHARToUTF8 Convert(*JsonStr);
	int32 BytesSent = 0;
	CommandSocket->SendTo((uint8*)Convert.Get(), Convert.Length(), BytesSent, *Addr);
}

void UHFCommandChannel::SendStorePose()
{
	SendJson(TEXT("{\"cmd\":\"store_pose\"}"));
}

void UHFCommandChannel::SendResetPose()
{
	SendJson(TEXT("{\"cmd\":\"reset_pose\"}"));
}

void UHFCommandChannel::SendAnchorAruco()
{
	SendJson(TEXT("{\"cmd\":\"anchor_aruco\"}"));
}

void UHFCommandChannel::SendAnchorLidar(FVector MarkerMapPosition, FRotator MarkerMapRotation, FString MapFilePath)
{
	// Position is already in metres (converted by HFLidarAnchor::GetMarkerMapTransform)
	FString Json = FString::Printf(
		TEXT("{\"cmd\":\"anchor_lidar\","
			 "\"marker_map_position\":[%f,%f,%f],"
			 "\"marker_map_rotation\":[%f,%f,%f],"
			 "\"map_file\":\"%s\"}"),
		MarkerMapPosition.X, MarkerMapPosition.Y, MarkerMapPosition.Z,
		MarkerMapRotation.Roll, MarkerMapRotation.Pitch, MarkerMapRotation.Yaw,
		*MapFilePath);
	SendJson(Json);
}

void UHFCommandChannel::SendOffset(FVector Translation, FRotator Rotation, float Scale)
{
	FString Json = FString::Printf(TEXT("{\"cmd\":\"set_offset\", \"tx\":%f, \"ty\":%f, \"tz\":%f, \"rx\":%f, \"ry\":%f, \"rz\":%f, \"scale\":%f}"),
		Translation.X / 100.0f, // convert cm to m
		Translation.Y / 100.0f,
		Translation.Z / 100.0f,
		Rotation.Roll,
		Rotation.Pitch,
		Rotation.Yaw,
		Scale
	);
	SendJson(Json);
}

// ----------------------------------------------------------------------------------
// Background Status Thread
// ----------------------------------------------------------------------------------

UHFCommandChannel::FStatusRunnable::FStatusRunnable(UHFCommandChannel* InOwner)
	: Owner(InOwner), bShouldStop(false)
{
}

bool UHFCommandChannel::FStatusRunnable::Init()
{
	return true;
}

uint32 UHFCommandChannel::FStatusRunnable::Run()
{
	FSocket* Socket = FUdpSocketBuilder(TEXT("HFStatusSocket"))
		.AsNonBlocking()
		.AsReusable()
		.BoundToEndpoint(FIPv4Endpoint(FIPv4Address::Any, Owner->StatusPort))
		.WithReceiveBufferSize(65536);

	if (!Socket) return 0;

	ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
	TSharedRef<FInternetAddr> Sender = SocketSubsystem->CreateInternetAddr();

	// One extra byte so the payload can always be NUL-terminated in place. The
	// datagram is not terminated on the wire, so decoding it as a C string would
	// run past the frame into whatever the previous, longer datagram left behind.
	TArray<uint8> RecvBuffer;
	RecvBuffer.SetNumUninitialized(4097);

	while (!bShouldStop)
	{
		uint32 Size = 0;
		while (!bShouldStop && Socket->HasPendingData(Size))
		{
			int32 Read = 0;
			if (!Socket->RecvFrom(RecvBuffer.GetData(), RecvBuffer.Num() - 1, Read, *Sender))
			{
				break;
			}

			if (Read > 0)
			{
				RecvBuffer[Read] = 0;
				const FString JsonStr = FString(UTF8_TO_TCHAR(reinterpret_cast<const ANSICHAR*>(RecvBuffer.GetData())));

				FScopeLock Lock(&Owner->StatusLock);
				Owner->PendingStatusJson = JsonStr;
				Owner->bNewStatusReady = true;
			}
		}
		FPlatformProcess::Sleep(0.1f); // 10 hz check rate for status is plenty
	}

	Socket->Close();
	SocketSubsystem->DestroySocket(Socket);
	return 0;
}

void UHFCommandChannel::FStatusRunnable::Stop()
{
	bShouldStop = true;
}

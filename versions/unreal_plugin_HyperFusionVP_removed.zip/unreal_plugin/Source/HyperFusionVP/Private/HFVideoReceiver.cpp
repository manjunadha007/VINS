#include "HFVideoReceiver.h"
#include "Common/UdpSocketBuilder.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Modules/ModuleManager.h"
#include "RHI.h"
#include "Sockets.h"
#include "SocketSubsystem.h"

// Matches MAX_UDP_PAYLOAD in bridge_headless.py (65000) plus the 4-byte header.
static constexpr int32 HF_VIDEO_RECV_BUFFER = 65536;

UHFVideoReceiver::UHFVideoReceiver()
{
	PrimaryComponentTick.bCanEverTick = true;
	// We want to tick every frame to check for new video data
	PrimaryComponentTick.TickGroup = TG_PrePhysics;
}

void UHFVideoReceiver::BeginPlay()
{
	Super::BeginPlay();

	// Start the background UDP receiver thread
	Runnable = new FReceiverRunnable(this);
	ReceiverThread = FRunnableThread::Create(Runnable, TEXT("HFVideoReceiverThread"), 0, TPri_Normal);
}

void UHFVideoReceiver::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (Runnable)
	{
		Runnable->Stop();
		if (ReceiverThread)
		{
			ReceiverThread->WaitForCompletion();
			delete ReceiverThread;
			ReceiverThread = nullptr;
		}
		delete Runnable;
		Runnable = nullptr;
	}

	Super::EndPlay(EndPlayReason);
}

void UHFVideoReceiver::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bNewFrameReady)
	{
		ProcessPendingFrame();
	}

	// Roll the frame counter into a displayable rate once a second.
	FpsAccumulator += DeltaTime;
	if (FpsAccumulator >= 1.0f)
	{
		VideoFps = FramesThisSecond / FpsAccumulator;
		FramesThisSecond = 0;
		FpsAccumulator = 0.0f;
	}
}

void UHFVideoReceiver::SetOpacity(float NewOpacity)
{
	Opacity = FMath::Clamp(NewOpacity, 0.0f, 1.0f);
}

void UHFVideoReceiver::SetOverlayVisible(bool bVisible)
{
	bShowOverlay = bVisible;
}

void UHFVideoReceiver::CreateOrResizeTexture(int32 Width, int32 Height)
{
	if (!VideoTexture || VideoTexture->GetSizeX() != Width || VideoTexture->GetSizeY() != Height)
	{
		// Format must match the decoded pixel format (BGRA8)
		VideoTexture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
		if (VideoTexture)
		{
			// Optimization for frequently updated textures
			VideoTexture->CompressionSettings = TC_VectorDisplacementmap; // No compression
			VideoTexture->SRGB = 0;
			VideoTexture->Filter = TF_Bilinear;
			// No AddToRoot: the UPROPERTY above already keeps this alive for the
			// component's lifetime, and rooting would strand the previous texture
			// every time the stream changes resolution.
			VideoTexture->UpdateResource();
			UE_LOG(LogTemp, Log, TEXT("[HFVideoReceiver] Created new texture %dx%d"), Width, Height);
		}
	}
}

void UHFVideoReceiver::ProcessPendingFrame()
{
	// Take the frame under the lock, then release it before doing the upload so the
	// network thread is never blocked behind a texture copy.
	TArray64<uint8> FrameCopy;
	int32 Width = 0;
	int32 Height = 0;
	{
		FScopeLock Lock(&FrameLock);
		if (PendingFrameData.Num() == 0 || PendingWidth <= 0 || PendingHeight <= 0)
		{
			bNewFrameReady = false;
			return;
		}
		FrameCopy = MoveTemp(PendingFrameData);
		PendingFrameData.Reset();
		Width = PendingWidth;
		Height = PendingHeight;
		bNewFrameReady = false;
	}

	const int64 ExpectedBytes = static_cast<int64>(Width) * Height * 4;
	if (FrameCopy.Num() < ExpectedBytes)
	{
		UE_LOG(LogTemp, Warning, TEXT("[HFVideoReceiver] Short frame: %lld bytes, expected %lld"),
		       static_cast<long long>(FrameCopy.Num()), static_cast<long long>(ExpectedBytes));
		return;
	}

	CreateOrResizeTexture(Width, Height);
	if (!VideoTexture)
	{
		return;
	}

	// UpdateTextureRegions hands both allocations to the render thread and invokes
	// the cleanup lambda once the upload has retired, so neither may be stack memory.
	FUpdateTextureRegion2D* Region = new FUpdateTextureRegion2D(0, 0, 0, 0, Width, Height);
	uint8* SrcData = new uint8[ExpectedBytes];
	FMemory::Memcpy(SrcData, FrameCopy.GetData(), ExpectedBytes);

	VideoTexture->UpdateTextureRegions(
		0, 1, Region, static_cast<uint32>(Width * 4), 4, SrcData,
		[](uint8* InSrcData, const FUpdateTextureRegion2D* InRegions)
		{
			delete[] InSrcData;
			delete InRegions;
		});

	bHasReceivedFrame = true;
	++FramesThisSecond;
}


// ----------------------------------------------------------------------------------
// Background Receiver Thread
// ----------------------------------------------------------------------------------

UHFVideoReceiver::FReceiverRunnable::FReceiverRunnable(UHFVideoReceiver* InOwner)
	: Owner(InOwner), bShouldStop(false)
{
}

bool UHFVideoReceiver::FReceiverRunnable::Init()
{
	return true;
}

uint32 UHFVideoReceiver::FReceiverRunnable::Run()
{
	FSocket* Socket = FUdpSocketBuilder(TEXT("HFVideoSocket"))
		.AsNonBlocking()
		.AsReusable()
		.BoundToEndpoint(FIPv4Endpoint(FIPv4Address::Any, Owner->ListenPort))
		.WithReceiveBufferSize(2 * 1024 * 1024);

	if (!Socket)
	{
		UE_LOG(LogTemp, Error, TEXT("[HFVideoReceiver] Failed to bind UDP socket on port %d"), Owner->ListenPort);
		return 0;
	}

	UE_LOG(LogTemp, Log, TEXT("[HFVideoReceiver] Listening for video on port %d"), Owner->ListenPort);

	ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
	TSharedRef<FInternetAddr> Sender = SocketSubsystem->CreateInternetAddr();

	// Load the image wrapper module once
	IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
	TSharedPtr<IImageWrapper> JpegWrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::JPEG);

	TArray<uint8> RecvBuffer;
	RecvBuffer.SetNumUninitialized(HF_VIDEO_RECV_BUFFER);

	while (!bShouldStop)
	{
		uint32 Size = 0;
		while (!bShouldStop && Socket->HasPendingData(Size))
		{
			int32 Read = 0;
			if (!Socket->RecvFrom(RecvBuffer.GetData(), RecvBuffer.Num(), Read, *Sender))
			{
				break;
			}

			// Protocol: 4 bytes big-endian length + JPEG payload
			if (Read <= 4)
			{
				continue;
			}

			const uint32 PayloadLen =
				(static_cast<uint32>(RecvBuffer[0]) << 24) |
				(static_cast<uint32>(RecvBuffer[1]) << 16) |
				(static_cast<uint32>(RecvBuffer[2]) << 8) |
				 static_cast<uint32>(RecvBuffer[3]);

			// A datagram that claims more than it carries is a truncated frame, not a
			// partial one: UDP gives us whole datagrams or nothing, so drop it.
			if (PayloadLen == 0 || PayloadLen > static_cast<uint32>(Read - 4))
			{
				continue;
			}

			if (!JpegWrapper.IsValid() || !JpegWrapper->SetCompressed(RecvBuffer.GetData() + 4, PayloadLen))
			{
				continue;
			}

			TArray64<uint8> UncompressedBGRA;
			if (!JpegWrapper->GetRaw(ERGBFormat::BGRA, 8, UncompressedBGRA))
			{
				continue;
			}

			FScopeLock Lock(&Owner->FrameLock);
			Owner->PendingWidth = JpegWrapper->GetWidth();
			Owner->PendingHeight = JpegWrapper->GetHeight();
			Owner->PendingFrameData = MoveTemp(UncompressedBGRA);
			Owner->bNewFrameReady = true;
		}
		// Don't starve the CPU
		FPlatformProcess::Sleep(0.005f); // 5ms sleep (~200 hz check rate)
	}

	Socket->Close();
	SocketSubsystem->DestroySocket(Socket);
	return 0;
}

void UHFVideoReceiver::FReceiverRunnable::Stop()
{
	bShouldStop = true;
}

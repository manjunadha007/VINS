#include "HyperFusionVPModule.h"
#include "Engine/Engine.h"
#include "Misc/CoreDelegates.h"

#define LOCTEXT_NAMESPACE "FHyperFusionVPModule"

void FHyperFusionVPModule::StartupModule()
{
	UE_LOG(LogTemp, Log, TEXT("[HyperFusionVP] Plugin loaded."));

	// GEngine does not exist yet at Default loading phase, so capping here would be
	// a silent no-op. Defer to the point where the console manager is live.
	if (GEngine)
	{
		ApplyFrameRateCap();
	}
	else
	{
		PostEngineInitHandle = FCoreDelegates::GetOnPostEngineInit().AddRaw(this, &FHyperFusionVPModule::ApplyFrameRateCap);
	}
}

void FHyperFusionVPModule::ApplyFrameRateCap()
{
	if (!GEngine)
	{
		return;
	}

	// Leave GPU headroom for cuVSLAM: Unreal at 30 fps, tracking keeps its 90 Hz.
	GEngine->Exec(nullptr, TEXT("t.MaxFPS 30"));
	UE_LOG(LogTemp, Warning, TEXT("[HyperFusionVP] FPS capped to 30 for tracking stability (RTX 3060)."));
}

void FHyperFusionVPModule::ShutdownModule()
{
	if (PostEngineInitHandle.IsValid())
	{
		FCoreDelegates::GetOnPostEngineInit().Remove(PostEngineInitHandle);
		PostEngineInitHandle.Reset();
	}

	UE_LOG(LogTemp, Log, TEXT("[HyperFusionVP] Plugin unloaded."));
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FHyperFusionVPModule, HyperFusionVP)

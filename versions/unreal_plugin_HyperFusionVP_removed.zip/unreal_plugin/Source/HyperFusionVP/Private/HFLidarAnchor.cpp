#include "HFLidarAnchor.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "UObject/ConstructorHelpers.h"
#include "EngineUtils.h"

AHFLidarAnchor::AHFLidarAnchor()
{
    PrimaryActorTick.bCanEverTick = false;

    USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    SetRootComponent(Root);

    // Visual marker plane (editor only, hidden in game)
    MarkerMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MarkerMesh"));
    MarkerMesh->SetupAttachment(Root);
    MarkerMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    MarkerMesh->SetHiddenInGame(true);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> PlaneMesh(
        TEXT("/Engine/BasicShapes/Plane.Plane"));
    if (PlaneMesh.Succeeded())
    {
        MarkerMesh->SetStaticMesh(PlaneMesh.Object);
        // Scale to marker size (Plane is 100x100 uu)
        MarkerMesh->SetRelativeScale3D(FVector(0.001f, 0.001f, 1.0f));
    }
}

FTransform AHFLidarAnchor::GetMarkerMapTransform() const
{
    FTransform T = GetActorTransform();
    // Convert from Unreal cm to metres for the bridge
    FVector Pos = T.GetLocation() / 100.0f;
    T.SetLocation(Pos);
    return T;
}

AHFLidarAnchor* AHFLidarAnchor::Get(const UObject* WorldContextObject)
{
    if (!WorldContextObject) return nullptr;
    UWorld* World = GEngine
        ? GEngine->GetWorldFromContextObject(WorldContextObject,
                                              EGetWorldErrorMode::ReturnNull)
        : nullptr;
    if (!World) return nullptr;
    TActorIterator<AHFLidarAnchor> It(World);
    return It ? *It : nullptr;
}

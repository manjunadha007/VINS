#include "HFVideoOverlay.h"
#include "HFVideoReceiver.h"
#include "Blueprint/WidgetTree.h"
#include "Components/Image.h"
#include "Components/ScaleBox.h"
#include "Components/ScaleBoxSlot.h"

UHFVideoOverlay::UHFVideoOverlay(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	// The root must stay arranged for the lifetime of the widget. SWidget::Tick is
	// invoked from inside SWidget::Paint, and a Collapsed widget is never arranged
	// and so never painted — collapsing the root here would stop NativeTick from
	// ever running, and nothing could un-collapse it. Blanking is done on the
	// child image instead. SelfHitTestInvisible keeps it out of the input path.
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

static EStretch::Type ToStretch(EHFOverlayFit Fit)
{
	switch (Fit)
	{
	case EHFOverlayFit::FitWidth:  return EStretch::ScaleToFitX;
	case EHFOverlayFit::FitHeight: return EStretch::ScaleToFitY;
	case EHFOverlayFit::Fit:       return EStretch::ScaleToFit;
	case EHFOverlayFit::Fill:      return EStretch::ScaleToFill;
	case EHFOverlayFit::Stretch:   return EStretch::Fill;
	default:                       return EStretch::ScaleToFitX;
	}
}

TSharedRef<SWidget> UHFVideoOverlay::RebuildWidget()
{
	if (!WidgetTree->RootWidget)
	{
		// A ScaleBox does the fitting for us: it measures the child at its natural
		// size (the brush size, which we set to the video resolution) and scales it
		// to the rule below. That keeps aspect handling out of per-frame maths.
		ScaleBoxRoot = WidgetTree->ConstructWidget<UScaleBox>(UScaleBox::StaticClass(), TEXT("VideoScaleBox"));
		VideoImage = WidgetTree->ConstructWidget<UImage>(UImage::StaticClass(), TEXT("VideoImage"));

		if (UScaleBoxSlot* BoxSlot = Cast<UScaleBoxSlot>(ScaleBoxRoot->AddChild(VideoImage)))
		{
			BoxSlot->SetHorizontalAlignment(HAlign_Center);
			BoxSlot->SetVerticalAlignment(VAlign_Center);
		}

		ScaleBoxRoot->SetStretch(ToStretch(Fit));
		WidgetTree->RootWidget = ScaleBoxRoot;
	}

	return Super::RebuildWidget();
}

void UHFVideoOverlay::SetReceiver(UHFVideoReceiver* InReceiver)
{
	Receiver = InReceiver;
}

void UHFVideoOverlay::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (!VideoImage || !ScaleBoxRoot)
	{
		return;
	}

	UHFVideoReceiver* Rx = Receiver.Get();
	const bool bVisible = Rx && Rx->bShowOverlay && Rx->HasVideoSignal();

	// Blank the image, never the root — see the constructor for why.
	const ESlateVisibility Wanted = bVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed;
	if (VideoImage->GetVisibility() != Wanted)
	{
		VideoImage->SetVisibility(Wanted);
	}

	if (!bVisible)
	{
		return;
	}

	UTexture2D* Tex = Rx->VideoTexture;
	if (Tex && LastTexture.Get() != Tex)
	{
		// bMatchSize stamps the brush with the texture's dimensions, which is what
		// gives the ScaleBox a real aspect ratio to fit. The receiver builds a new
		// texture whenever the resolution changes, so comparing the object pointer
		// is enough to catch a stream that switches size mid-run.
		VideoImage->SetBrushFromTexture(Tex, /*bMatchSize=*/ true);
		LastTexture = Tex;

		UE_LOG(LogTemp, Log, TEXT("[HFVideoOverlay] Showing %dx%d feed (fit %d)."),
		       Tex->GetSizeX(), Tex->GetSizeY(), static_cast<int32>(Fit));
	}

	VideoImage->SetColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f, Rx->Opacity));

	ScaleBoxRoot->SetStretch(ToStretch(Fit));
	ScaleBoxRoot->SetUserSpecifiedScale(FitScale);
	ScaleBoxRoot->SetRenderScale(FVector2D(FitScale, FitScale));
}

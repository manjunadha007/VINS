#include "HFTrackingOrigin.h"
#include "HFCommandChannel.h"
#include "Engine/World.h"
#include "EngineUtils.h"

AHFTrackingOrigin::AHFTrackingOrigin()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	CommandChannel = CreateDefaultSubobject<UHFCommandChannel>(TEXT("CommandChannel"));
}

void AHFTrackingOrigin::PushTransformAsOffset()
{
	if (!CommandChannel)
	{
		return;
	}

	const FTransform T = GetActorTransform();
	// Uniform scale only: the bridge applies a single scalar, so a non-uniform
	// actor scale would silently lose two of its three axes.
	const FVector S = T.GetScale3D();
	const float Scale = (S.X + S.Y + S.Z) / 3.0f;

	CommandChannel->SendOffset(T.GetLocation(), T.GetRotation().Rotator(), Scale);
}

void AHFTrackingOrigin::StorePose()
{
	if (CommandChannel)
	{
		CommandChannel->SendStorePose();
	}
}

void AHFTrackingOrigin::ResetPose()
{
	if (CommandChannel)
	{
		CommandChannel->SendResetPose();
	}
}

AHFTrackingOrigin* AHFTrackingOrigin::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject)
	{
		return nullptr;
	}

	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	if (!World)
	{
		return nullptr;
	}

	// First one wins: a level with two origins is a setup mistake, not a case to
	// disambiguate here.
	TActorIterator<AHFTrackingOrigin> It(World);
	return It ? *It : nullptr;
}

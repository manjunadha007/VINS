using UnrealBuildTool;

public class HyperFusionVP : ModuleRules
{
	public HyperFusionVP(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore",
			"Networking",
			"Sockets",
			"RenderCore",
			"RHI",
			"ImageWrapper",
			"CinematicCamera",
			"LiveLinkInterface",
			"LiveLinkComponents",
			"UMG",
			"Slate",
			"SlateCore"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Json",
			"JsonUtilities"
		});
	}
}

# HyperFusionVP — Unreal Engine Virtual Production Plugin

Phase 2 of the HyperFusion pipeline. The ROS/SLAM side stays headless on Linux;
visualization, alignment and control move into Unreal Editor.

```
Linux host                                  Unreal Engine 5.8
──────────                                  ─────────────────
RealSense D455 ─┬─> Isaac ROS cuVSLAM ─┐
                │                      ├─> bridge_headless.py
                └──────────────────────┘         │
                                                 ├── 11111 FreeD ──> LiveLink ──> CineCamera
                                                 ├── 11112 JPEG  ──> HFVideoReceiver
                                                 ├── 11113 status ─> HFCommandChannel
                                                 └── 11114 cmds  <── HFCommandChannel
```

| Port | Direction | Payload |
|---|---|---|
| 11111 | bridge → UE | FreeD D1 camera position packets |
| 11112 | bridge → UE | 4-byte big-endian length + JPEG frame |
| 11113 | bridge → UE | status JSON, one object per datagram |
| 11114 | UE → bridge | command JSON (`store_pose`, `reset_pose`, `set_offset`, `anchor_aruco`) |

## Layout

```
Source/HyperFusionVP/
  Public|Private/
    HyperFusionVPModule    caps t.MaxFPS to 30 once the engine is up
    HFVideoReceiver        UActorComponent: UDP JPEG -> UTexture2D
    HFCommandChannel       UActorComponent: bidirectional UDP JSON
    HFTrackingOrigin       AActor: the real-world origin, owns the command channel
    HFTrackedCamera        ACineCameraActor: hosts the overlay in either mode
    HFVideoOverlay         UUserWidget: full-viewport screen-space feed (default)
    HFAlignmentPanel       UUserWidget base: all panel behaviour
Content/HyperFusionVP/
  Materials/M_CameraOverlay      translucent unlit, params "VideoTexture" + "Opacity"
  Blueprints/BP_TrackingOrigin   subclass of AHFTrackingOrigin
  Blueprints/BP_TrackedCamera    subclass of AHFTrackedCamera
  UI/WBP_AlignmentPanel          subclass of UHFAlignmentPanel
Tools/
  hf_build_content.py      generates the four assets above
  hf_verify_content.py     asserts they are wired correctly
```

Behaviour lives in C++ so the Blueprints stay thin — none of them needs an event
graph. That also means the assets are regenerable rather than hand-maintained.

## Build

The host project must be a code project. `MyProject` was Blueprint-only, so it
now carries a minimal `Source/` (two `.Target.cs` files and an empty module).
UBT cannot compile a C++ plugin without it — it invents temporary targets for
three platforms and then fails with `Unable to perform hot reload with multiple
targets`.

```bash
cd /home/kiransai/UnrealEngine_5.8.1
./Engine/Build/BatchFiles/Linux/Build.sh MyProjectEditor Linux Development \
    -Project="/home/kiransai/Documents/Unreal Projects/MyProject/MyProject.uproject" -Progress
```

**Prefer the wrapper** — `Tools/hf_build.sh` does the above and then repairs the
module manifest:

```bash
./unreal_plugin/Tools/hf_build.sh           # build + repair manifest
./unreal_plugin/Tools/hf_build.sh --clean   # wipe first (editor must be closed)
```

> **Why the wrapper exists.** Successive builds emit numbered libraries
> (`libUnrealEditor-HyperFusionVP-0003.so`) but UBT only rewrites
> `Binaries/Linux/UnrealEditor.modules` on a clean build. Whenever the editor is
> open — i.e. whenever you are testing — the manifest keeps naming an older
> number and the editor loads stale code on next launch. The build still says
> `Succeeded`, so it reads as "my change did nothing" rather than a build
> failure. This has caused two separate false diagnoses in this project already.
>
> Restarting the editor is required to pick up a rebuilt module; stopping PIE is
> not enough.

After any C++ change that **adds or removes a component**, re-run
`hf_build_content.py`: it recompiles the Blueprints against the new parent. Plain
properties propagate on their own, but a new component subobject does not, and
the Blueprint will silently lack it at runtime.

## Generate and check the content assets

`.uasset` files are binary, so they are produced by the editor rather than
checked in by hand. Both scripts run headless:

```bash
UE=/home/kiransai/UnrealEngine_5.8.1
PROJ="/home/kiransai/Documents/Unreal Projects/MyProject/MyProject.uproject"

$UE/Engine/Binaries/Linux/UnrealEditor-Cmd "$PROJ" -run=pythonscript \
    -script="<repo>/unreal_plugin/Tools/hf_build_content.py" -unattended -nopause -nosplash

$UE/Engine/Binaries/Linux/UnrealEditor-Cmd "$PROJ" -run=pythonscript \
    -script="<repo>/unreal_plugin/Tools/hf_verify_content.py" -unattended -nopause -nosplash \
    -stdout -LogCmds="LogPython Display"
```

`hf_build_content.py` skips anything that already exists; pass `--force` to
rebuild from scratch. `hf_verify_content.py` exits non-zero on any problem.

## Remaining manual step: the panel layout

`WBP_AlignmentPanel` is created with the right parent class but no widget tree —
Unreal exposes no supported Python API for building one. Open it and add these,
matching the names exactly. Every binding is `BindWidgetOptional`, so a partial
panel still compiles and runs; the controls you skip are simply inert.

| Widget name | Type | Purpose |
|---|---|---|
| `StatusText` | TextBlock | TRACKING / WAITING / LOST, colour-coded |
| `FpsText` | TextBlock | SLAM → FreeD rates, video fps, gate rejects |
| `MarkerText` | TextBlock | ArUco status |
| `GpuReminderText` | TextBlock | FPS cap notice |
| `OverlayToggle` | CheckBox | show/hide camera feed |
| `OpacitySlider` | Slider | 0…1 overlay opacity |
| `StorePoseButton` | Button | lock alignment |
| `ResetPoseButton` | Button | clear alignment |
| `SliderX` `SliderY` `SliderZ` | Slider | translation offset |
| `SliderRoll` `SliderPitch` `SliderYaw` | Slider | rotation offset |
| `SliderScale` | Slider | scale |

All offset sliders run 0…1 with **0.5 as neutral**. Translation maps to
±`TranslationRangeCm` (200 cm default), rotation to ±`RotationRangeDeg` (180°),
and scale to 0.5×…1.5×. Change the ranges on the widget's class defaults.

## Overlay modes

`BP_TrackedCamera > HyperFusion|Overlay > OverlayMode` picks how the feed draws.

**`ScreenSpace` (default)** — a full-viewport UMG layer, created automatically at
`BeginPlay`. It fills the 3D window whatever the focal length, filmback or view
angle, which is what you want for checking that the CG lines up with the plate.
There is no Widget Blueprint to lay out: `UHFVideoOverlay` builds its own tree in
C++. Fitting is a `Fit` property on the widget class:

| `Fit` | Result |
|---|---|
| `FitWidth` *(default)* | spans the full window width, letterboxed top/bottom, aspect kept |
| `FitHeight` | spans the full height, pillarboxed, aspect kept |
| `Fit` | largest size fully on screen, aspect kept |
| `Fill` | covers the window, crops overflow, aspect kept |
| `Stretch` | exact window fit, **distorts** |

`FitScale` insets the plate below 1.0 if you want it smaller than the fit rule.
`ScreenOverlayZOrder` is −10 so the plate sits under the alignment panel, which
adds at 0.

**`WorldQuad`** — the original quad parented to the lens, auto-scaled to the
camera frustum. It composites correctly *in camera* and moves with the rig, but
only looks right when you are viewing through `BP_TrackedCamera`; from a free
viewport it is a ~1 m object in the level and reads as tiny. This mode is the one
that needs `OverlayMaterial` assigned.

Both modes read visibility and opacity from the same `UHFVideoReceiver`, so the
panel's `OverlayToggle` and `OpacitySlider` drive whichever is active with no
extra wiring.

Either way the overlay only appears in **PIE / the game viewport** — the UDP
receiver starts at `BeginPlay`, so an editor viewport with nothing playing has no
feed to show.

## Level setup

1. Drop **BP_TrackingOrigin** into the level. Drag/rotate it to align the virtual
   world with the physical space. One per level — `AHFTrackingOrigin::Get` takes
   the first it finds.
2. Drop **BP_TrackedCamera** in and parent it to the origin.
3. Only for `WorldQuad` mode: assign **M_CameraOverlay** to its `OverlayMaterial`
   (the generator does this already; check it survived if you regenerated). The
   default `ScreenSpace` mode does not use the material.
4. Wire up tracking — see below. Without this the camera never moves.
5. Add **WBP_AlignmentPanel** to the viewport.

## Making the camera actually move

The video path (11112) carries no pose. Camera motion arrives separately as FreeD
on 11111 and reaches the camera through Live Link, so running the bridge on its
own will not move anything.

`AHFTrackedCamera` already owns a `ULiveLinkComponentController`, so there is no
component to add. Two things are needed:

1. **Add the FreeD source.** *Window → Virtual Production → Live Link → + Source
   → FreeD*, listening on port **11111**. Start the bridge and a subject should
   appear. This step is manual because the FreeD connection-settings type lives
   in a private engine header and cannot be constructed from another plugin.
   Save it as a **LiveLinkPreset** asset and set that under *Project Settings →
   Live Link → Default Live Link Preset* to have it restored on every launch.
2. **Point the camera at the subject.** Put the subject's name in
   `BP_TrackedCamera > HyperFusion|LiveLink > LiveLinkSubject`. On `BeginPlay`
   the controller binds to it with `ULiveLinkCameraRole`. Leaving it empty logs a
   warning and the camera stays put.

### Why Play lands in the ThirdPerson character

`GlobalDefaultGameMode` is `BP_ThirdPersonGameMode_C`, so Play spawns that pawn
and views through it — nothing to do with this plugin. `bTakeViewOnPlay` (on by
default) calls `SetViewTarget` at `BeginPlay` so the tracked camera claims the
view instead. The pawn still spawns and still eats input; swap the GameMode or
the level's Game Mode Override if you want it gone entirely.

The overlay stays hidden until the first JPEG frame arrives, so an unstarted
bridge shows the 3D scene rather than a black rectangle.

## Testing without the camera

`test_video_stream.py` in the repo root speaks the same protocol as the bridge:

```bash
python3 test_video_stream.py serve              # fake bridge: video + status + command listener
python3 test_video_stream.py serve --marker     # also emit a fake ArUco detection
python3 test_video_stream.py sniff --port 11112 # validate real bridge framing
python3 test_video_stream.py sniff --port 11113 # watch status JSON
python3 test_video_stream.py send-cmd store_pose
```

`serve` streams a 640×480 pattern with a sweeping bar and a frame counter, so a
frozen texture is obvious at a glance.

## Not yet done

Step 5 polish from the plan: ArUco marker *visualization* in 3D (the status text
is wired, the in-world marker is not), GPU usage monitoring, and packaging the
plugin for distribution.
